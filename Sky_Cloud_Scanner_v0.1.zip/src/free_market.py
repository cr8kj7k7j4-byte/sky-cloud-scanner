"""
免費公開行情轉接層（prototype）

用途：
1. 用 Fugle intraday/tickers 取得上市/上櫃股票 universe（少量 API 呼叫）。
2. 用 TWSE MIS 公開看盤端點批次取得盤中報價，計算漲跌幅後排序。
3. 不把此來源視為有 SLA 的交易級即時行情；若官方端點調整或限制，
   程式應停止並回報，而不是用舊資料冒充即時資料。

注意：
- TWSE MIS 端點主要供網站看盤使用，並非承諾給自動化程式的正式付費 feed。
- 若未來穩定性不足，應改用合法授權的 Snapshot / 行情供應商。
"""
import math
import time
import requests
from .fugle import get_tickers

MIS_URL = "https://mis.twse.com.tw/stock/api/getStockInfo.jsp"

def _to_float(v):
    if v in (None, "", "-", "--"):
        return None
    try:
        return float(str(v).replace(",", ""))
    except Exception:
        return None

def _to_int(v):
    f = _to_float(v)
    return int(f) if f is not None else 0

def load_universe():
    out = []
    for exchange, market, prefix in [
        ("TWSE", "TSE", "tse"),
        ("TPEx", "OTC", "otc"),
    ]:
        rows = get_tickers(exchange, market)
        for x in rows:
            symbol = str(x.get("symbol", "")).strip()
            if not symbol or not symbol.isdigit():
                continue
            out.append({
                "symbol": symbol,
                "name": x.get("name", ""),
                "exchange": exchange,
                "market": market,
                "mis_prefix": prefix,
            })
    return out

def fetch_mis_quotes(universe, batch_size=60, sleep_s=0.25):
    session = requests.Session()
    session.headers.update({
        "User-Agent": "Mozilla/5.0 SkyCloudScanner/0.1",
        "Referer": "https://mis.twse.com.tw/stock/index.jsp",
    })
    # establish session/cookies
    try:
        session.get("https://mis.twse.com.tw/stock/index.jsp", timeout=15)
    except Exception:
        pass

    results = []
    for i in range(0, len(universe), batch_size):
        batch = universe[i:i+batch_size]
        ex_ch = "|".join(f'{x["mis_prefix"]}_{x["symbol"]}.tw' for x in batch)
        r = session.get(MIS_URL, params={"ex_ch": ex_ch, "json": "1", "delay": "0"}, timeout=20)
        r.raise_for_status()
        data = r.json().get("msgArray", [])
        by_symbol = {x["symbol"]: x for x in batch}
        for q in data:
            symbol = str(q.get("c", "")).strip()
            meta = by_symbol.get(symbol, {})
            last = _to_float(q.get("z"))
            prev = _to_float(q.get("y"))
            # If no last trade yet, do not infer from bid/ask.
            if last is None or prev in (None, 0):
                continue
            pct = (last / prev - 1.0) * 100.0
            results.append({
                **meta,
                "symbol": symbol,
                "name": q.get("n") or meta.get("name", ""),
                "last": last,
                "previous_close": prev,
                "change_pct": pct,
                "volume": _to_int(q.get("v")),
                "high": _to_float(q.get("h")),
                "low": _to_float(q.get("l")),
                "open": _to_float(q.get("o")),
                "quote_time": q.get("t", ""),
            })
        time.sleep(sleep_s)
    return results
