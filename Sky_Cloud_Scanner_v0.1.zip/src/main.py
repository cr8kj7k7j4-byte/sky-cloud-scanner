from datetime import datetime
from zoneinfo import ZoneInfo
from .config import TOP_N, DEEP_DIVE_N
from .free_market import load_universe, fetch_mis_quotes
from .fugle import get_ticker, get_quote, get_candles
from .sky_rules import first_gate, enrich_with_fugle_detail
from .notifier import send_telegram

TZ = ZoneInfo("Asia/Taipei")

def run():
    now = datetime.now(TZ)
    universe = load_universe()
    quotes = fetch_mis_quotes(universe)

    passed = []
    for q in quotes:
        ok, reasons = first_gate(q)
        if ok:
            passed.append(q)

    passed.sort(key=lambda x: (x["change_pct"], x["volume"]), reverse=True)
    top100 = passed[:TOP_N]

    # 免費 Fugle 方案避免一次深查 100 檔；
    # 僅深查前 N 檔，後續可把 Sky 的 Capital Acceleration / Relative Strength
    # 加到此處再縮小候選池。
    deep = []
    for row in top100[:DEEP_DIVE_N]:
        try:
            ticker = get_ticker(row["symbol"])
            quote = get_quote(row["symbol"])
            candles = get_candles(row["symbol"], "5")
            item = enrich_with_fugle_detail(row, ticker, quote, candles)
            if not item["is_limit_up"] and item["can_day_trade"]:
                deep.append(item)
        except Exception as e:
            item = dict(row)
            item["flags"] = [f"資料錯誤:{type(e).__name__}"]
            deep.append(item)

    lines = [
        f"Sky Cloud Scanner｜{now:%Y-%m-%d %H:%M}",
        f"全市場有效報價 {len(quotes)}｜第一層通過 {len(passed)}｜Top{len(top100)}",
        "",
        "【深查候選】",
    ]
    if not deep:
        lines.append("目前沒有完成深查的候選；不產生交易建議。")
    for i, x in enumerate(deep[:10], 1):
        flags = "、".join(x.get("flags", [])) or "待確認"
        lines.append(
            f'{i}. {x["symbol"]} {x.get("name","")} '
            f'{x["last"]:.2f} ({x["change_pct"]:+.2f}%) '
            f'量{x.get("volume",0):,}｜{flags}'
        )

    lines += [
        "",
        "註：此版本是候選掃描器，不等於進場訊號。",
        "未完成 Market Gate、SSS、Phase、Anti-Chase、Setup+Trigger、EES、RR 前，不列 A+。",
        "免費公開行情層無交易級 SLA；資料異常時應停止判斷。",
    ]
    send_telegram("\n".join(lines))

if __name__ == "__main__":
    run()
