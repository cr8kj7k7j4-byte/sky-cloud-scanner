import requests
from .config import FUGLE_API_KEY

BASE = "https://api.fugle.tw/marketdata/v1.0/stock"

def _headers():
    if not FUGLE_API_KEY:
        raise RuntimeError("Missing FUGLE_API_KEY")
    return {"X-API-KEY": FUGLE_API_KEY, "User-Agent": "SkyCloudScanner/0.1"}

def get_tickers(exchange: str, market: str):
    r = requests.get(
        f"{BASE}/intraday/tickers",
        params={"type": "EQUITY", "exchange": exchange, "market": market},
        headers=_headers(),
        timeout=20,
    )
    r.raise_for_status()
    payload = r.json()
    return payload.get("data", payload if isinstance(payload, list) else [])

def get_quote(symbol: str):
    r = requests.get(
        f"{BASE}/intraday/quote/{symbol}",
        headers=_headers(),
        timeout=20,
    )
    r.raise_for_status()
    return r.json()

def get_ticker(symbol: str):
    r = requests.get(
        f"{BASE}/intraday/ticker/{symbol}",
        headers=_headers(),
        timeout=20,
    )
    r.raise_for_status()
    return r.json()

def get_candles(symbol: str, timeframe: str = "5"):
    r = requests.get(
        f"{BASE}/intraday/candles/{symbol}",
        params={"timeframe": timeframe, "sort": "asc"},
        headers=_headers(),
        timeout=20,
    )
    r.raise_for_status()
    return r.json()
