import os

FUGLE_API_KEY = os.getenv("FUGLE_API_KEY", "").strip()
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()

MAX_PRICE = float(os.getenv("MAX_PRICE", "100"))
TOP_N = int(os.getenv("TOP_N", "100"))
DEEP_DIVE_N = int(os.getenv("DEEP_DIVE_N", "12"))
MIN_VOLUME = int(os.getenv("MIN_VOLUME", "500"))
