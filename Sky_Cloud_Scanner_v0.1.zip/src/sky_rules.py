from .config import MAX_PRICE, MIN_VOLUME

def first_gate(row):
    reasons = []
    if row["last"] > MAX_PRICE:
        reasons.append(f"股價>{MAX_PRICE:g}")
    if row.get("volume", 0) < MIN_VOLUME:
        reasons.append(f"量<{MIN_VOLUME}張")
    return len(reasons) == 0, reasons

def enrich_with_fugle_detail(row, ticker, quote, candles):
    out = dict(row)
    out["can_day_trade"] = bool(ticker.get("canDayTrade"))
    out["can_buy_day_trade"] = bool(ticker.get("canBuyDayTrade"))
    out["limit_up"] = ticker.get("limitUpPrice")
    out["industry"] = ticker.get("industry")
    out["avg_price"] = quote.get("avgPrice")
    out["fugle_close"] = quote.get("closePrice")
    out["fugle_high"] = quote.get("highPrice")
    out["fugle_low"] = quote.get("lowPrice")
    out["is_limit_up"] = (
        out.get("limit_up") is not None
        and out.get("fugle_close") is not None
        and float(out["fugle_close"]) >= float(out["limit_up"])
    )

    k = candles.get("data", []) if isinstance(candles, dict) else []
    out["k_count"] = len(k)
    if len(k) >= 2:
        out["last_k_close"] = k[-1].get("close")
        out["prev_k_close"] = k[-2].get("close")
        out["last_k_volume"] = k[-1].get("volume")
        out["prev_k_volume"] = k[-2].get("volume")
    else:
        out["last_k_close"] = out["prev_k_close"] = None
        out["last_k_volume"] = out["prev_k_volume"] = None

    # 僅做客觀結構標籤，不冒充完整 Sky 分數。
    flags = []
    if out["is_limit_up"]:
        flags.append("X:漲停排除")
    if not out["can_day_trade"]:
        flags.append("X:不可當沖")
    if out.get("avg_price") and out.get("fugle_close"):
        flags.append("站上均價" if out["fugle_close"] >= out["avg_price"] else "低於均價")
    if out.get("last_k_volume") and out.get("prev_k_volume"):
        if out["last_k_volume"] > out["prev_k_volume"] * 1.5:
            flags.append("5分K量增")
    out["flags"] = flags
    return out
