# Sky Cloud Scanner｜免費雲端版 v0.1

目標：人在外面、不開電腦時，由 GitHub Actions 自動執行台股候選掃描，結果發到手機 Telegram。

## 架構

Fugle intraday/tickers（建立上市/上櫃 universe）
→ TWSE MIS 公開看盤端點（批次盤中報價，免費、非 SLA）
→ 股價 <= 100 / 成交量篩選
→ 漲幅 Top100
→ Fugle 免費 API 深查前 12 檔
→ 排除漲停 / 不可當沖
→ 5 分 K / 均價客觀標籤
→ Telegram

## 重要限制

1. 免費公開行情層不是交易級 SLA。若資料源拒絕雲端 IP、延遲、格式改動，程式應停止，不應拿舊值冒充即時行情。
2. v0.1 只做 Candidate Scanner，不會把主觀分數偽裝成勝率。
3. 尚未完成 Market Gate、SSS、Phase、Anti-Chase、Setup+Trigger、EES、RR Gate，因此不會自動宣告 A+。
4. Fugle 深查數量預設 12，避免免費額度被全市場掃描耗盡。
5. 實際交易前仍要確認報價時間、價格、量價與交易成本。

## GitHub 部署

1. 建立一個 Private repository。
2. 把本資料夾全部上傳。
3. Repository → Settings → Secrets and variables → Actions。
4. 建立：
   - FUGLE_API_KEY
   - TELEGRAM_BOT_TOKEN
   - TELEGRAM_CHAT_ID
5. Actions → Sky Cloud Scanner → Run workflow，先手動測試。
6. 確認 Telegram 收到訊息後，再依賴排程。

## Telegram Bot

1. 在 Telegram 找 @BotFather。
2. 建立 Bot，取得 Bot Token。
3. 對你的 Bot 傳一則訊息。
4. 用 Telegram Bot API getUpdates 找 chat_id。
5. 把 Token / Chat ID 放到 GitHub Secrets，禁止寫進程式碼。

## 預設掃描時間（台北）

09:05, 09:15, 09:30, 09:50, 10:10, 10:30,
11:00, 11:30, 12:00, 12:30, 13:00

## 下一版 P0-D

- 1/3/5 分鐘結構
- HH/HL/LH/LL
- Breakout/Pullback
- Structure Stop
- Capital Acceleration
- Relative Strength
- Anti-Chase / Anti-Dump Chase
- Setup + Trigger
- Net RR（含手續費、證交稅、滑價）
- A+ / A / X
- 實盤紀錄、MFE、MAE、R-Multiple

## 本機測試（可選）

```bash
pip install -r requirements.txt
cp .env.example .env
# 將環境變數載入後：
python -m src.main
```
